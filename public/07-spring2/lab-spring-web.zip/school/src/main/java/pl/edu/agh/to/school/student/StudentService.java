package pl.edu.agh.to.school.student;

import org.springframework.stereotype.Service;

import java.util.List;

@Service
public class StudentService {

}
