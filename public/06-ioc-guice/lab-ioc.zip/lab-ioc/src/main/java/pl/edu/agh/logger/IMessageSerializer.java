package pl.edu.agh.logger;

public interface IMessageSerializer {

    void serializeMessage(String message);
}
