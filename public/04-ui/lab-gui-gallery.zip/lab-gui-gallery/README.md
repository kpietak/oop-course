# Wskazówki dla prowadzącego

Pełne przykładowe rozwiązanie laborki znajduje się na branchu `solution` (oraz `additional-task` dla dodatkowego zadania). Poniżej wskazówki dla części studenckiej:

## Ogólny pomysł

- Skupiamy się na MVC jako wzorcu architektonicznym, a nie na technologii.
- Pokazujemy w jaki sposób odseparowane są od siebie poszczególne komponenty aplikacji.
- Pokazujemy sposób modelowania interakcji między komponentami i podkreślamy rolę wzorca `Observer` w tym wszystkim. Tak żeby każdy wiedział po tych zajęciach czym różni się wzorzec architektoniczny od projektowego i że mogą się one uzupełniać.
- Na tej laborce pokazujemy klasyczne MVC, na następnej MVP. Oznacza to, że w tym przypadku szczególnie ważne jest nasłuchiwanie na model. Żeby podkreślić sens tego wszystkiego mamy tu sporą sekcję o podpinaniu nasłuchiwania nie tylko przez widok, ale również przez zewnętrzny serwis (tu: `PhotoSerializer`). Dzięki temu możemy pokazać, jak nasłuchiwanie zabezpiecza nas przed różnymi problemami z gatunku "zaktualizowałem widok, ale zapomniałem zaktualizować przy okazji serwisu".

## Wstęp

Na początek proponuję bardzo krótko wprowadzić temat (max 10min):

1. Pokazać co się powinno stać po odpaleniu pobranej aplikacji (puste GUI) i zwrócić uwagę na to, że trzeba uruchamiać Gradlem żeby nie było problemów z JavaFX.
2. Spytać studentów o to, jaki wzorzec będziemy realizować. ;) Tak żeby padły nazwy 3 głównych komponentów i studenci wiedzieli jak je zlokalizować i po co to robić.
3. Bardzo krótko powiedzieć czym jest JavaFX i wyraźnie zaznaczyć, że to tylko technologia, a sam koncept jest od niej niezależny.
4. Opcjonalnie: ja zawsze robię płynne wprowadzenie do pierwszego zadania zanim studenci sami zaczną pracować. W tym przypadku można popytać, czy pamiętają czym jest Observer i zasugerować, po co on nam tu będzie w modelu.

Dodatkowo ja na zajęciach rysuję na tablicy wielkie trzy klocki (model, kontroler, widok) i potem w trakcie / na końcu staram się wraz z studentami dorysować strzałki między nimi na bazie tego, co zdziałali w kodzie.

## Model

Tu warto się upewnić, czy ludzie wiedzą jak przekształcić atrybuty na `Property`. Często padają pytania typu:

1. Jak zmapować obiekt dowolnego typu? 
   Odpowiedź: parametryzowane `ObjectProperty`.
2. Jak inicjować takie property? 
   Odpowiedź: podstawowa implementacja to `SimpleObjectProperty`, `SimpleStringProperty`, itp. Inicjować możemy bez podawania argumentów lub podając wartość początkową.
3. Czy mapować wszystkie atrybuty modelu? 
   Odpowiedź: W pierwszej części wystarczy nam zmapowanie atrybutów klasy `Photo`, ale jak ktoś z rozmachu zrobi też `Gallery` to ok, grunt by zastosował dobre typy właściwości.

## Kontroler

1. Połączenie kontrolera z widokiem powinno być proste, może paść pytanie o to kiedy FX to wszystko inicjuje. Odpowiedź brzmi: tuż po utworzeniu klasy kontrolera, ale przed zwróceniem jej z loadera FXML (można w tym momencie pokazać kod inicjujący w `GalleryApp`).
2. Przy łączeniu kontrolera z modelem studenci na pewno zaczną się zastanawiać, które property z widoku podpiąć pod model obrazka. 
   1. Dla `TextField` będzie to `textProperty()`, które łączymy z `nameProperty()`.
   2. Dla `ImageView` będzie to `imageProperty()`, które łączymy z `photoDataProperty()`.
3. Może się też pojawić problemu "kierunku bindowania". Warto to omówić - gdy robimy `x.bind(y)`, oczekujemy że w przypadku zmian `y`, zaktualizuje się wartość `x` (odwrotnie nie, chyba że zrobimy `bindBidirectional()`). Warto też wspomnieć, że `bind()` synchronizuje wartości również tuż po ustawieniu bindingu. 
4. Na podstawie "rozważań o kierunku bindowania" zwrócić uwagę, że nie da się zmienić z innego miejsca wartości, która jest wynikiem synchronizacji - w naszym przypadku użytkownik nie może zmienić wartości nazwy zdjęcia w `TextField` -> naprawimy to w kolejnym zadaniu.

## Interakcje w GUI

### Obsługa listy zdjęć

1. Tu mogą być wątpliwości co do `ListView` - o ile łatwo domyślić się, że tak się nazywa typ tej kontrolki patrząc w FXML, o tyle nie jest oczywiste, że jest to typ parametryzowany i w naszym kodzie powinniśmy zadeklarować atrybut jako `ListView<Photo>`. 
2. Może się pojawić pytanie o metodę `initialize()` - jest ona wołana po wstrzyknięciu wszystkich pól `@FXML`, a więc służy do dodatkowego inicjowania kontrolek, które na etapie konstruktora nie byłyby jeszcze wstrzyknięte.

Warto również omówić obserwowalną listę, choć w konspekcie jest ona podana kawa na ławę więc nie powinno być problemu z rozwiązaniem (co najwyżej z jego zrozumieniem).

### Interakcje w GUI

1. Upewnić się, że wszyscy wiedzą jak pisze się lambdy w Javie. Po poprzedniej laborce nie powinna to być nowość, ale różnie bywa.
2. Po dodaniu listenera do listy i doprowadzeniu do działania zapisywania warto prześledzić ze studentami cały flow, żeby wiedzieli kiedy gdzie jaki event poleci.
3. Warto również ustalić różnicę między bindowaniem a dodawaniem listenerów - w tym drugim przypadku wartości nie są synchronizowane na początku i nie ma ograniczenia pt. "skoro x nasłuchuje na y to z nie może już zmodyfikować x".
4. Zwrócić uwagę na miejsce, w którym studenci próbują wstawić listener zmieniający nazwę zdjęcia - powinno to się dziać wewnątrz listenera na zmiany w liście, bo inaczej pominiemy jakieś zdjęcia, które zostaną dodane do modelu w późniejszym czasie.

## Obsługa długich operacji

W przypadku szukajki przewidywane problemy powinny pojawić się dopiero w obsłudze kliknięcia w przycisk. Zwrócić uwagę, żeby studenci nie próbowali  bawić się niepotrzebnie w stylowanie przycisku i layoutu (czasem im się to zdarza ;) ).

1. Jak przekazać do wyszukiwania treść `TextField`a? 
   Odpowiedź: użyć `getText()`, które pobiera **aktualną** wartość `textProperty()`.
2. Omówić dokładnie problemy wątków w dużych operacjach:
   1. Jeśli mamy jeden wątek to UI nie może się odświeżać w trakcie wykonywania operacji -> efekt zamrożenia, unikamy tego!
   2. Jeśli mamy osobny wątek na obliczenia to musimy uważać by nie aktualizował on bezpośrednio kontrolek. FX nie pozwala na modyfikację UI z kilku różnych wątków, bo prowadziłoby to do artefaktów wizualnych i spektakularnych wybuchów całej aplikacji.
   3. Potrzebujemy więc osobnego wątku + przełączki na wątek UI. Tę zapewnia nam `Platform.runLater()`, który kolejkuje zdarzenia na wątku UI. Można też używać RXowego `JavaFXScheduler.platform()`. Warto tu wspomnieć, że na Androidzie działa to bardzo podobnie, studenci lubią realistyczne przykłady (szczególnie gdy narzekają na to, że FX jest stary).
   4. Jeśli ktoś zwróci uwagę, że samo zapisywanie zdjęć na dysk też zamula to można odesłać do dodatkowego zadania. :)

Na koniec zajęć należy upewnić się czy zostały omówione wszystkie rodzaje interakcji między komponentami i czy "strzałki między klockami" na tablicy tworzą koło: użytkownik aktualizuje UI -> UI przekazuje akcję do kontrolera -> kontroler aktualizuje model -> model powiadamia nasłuchujący na niego widok (oraz inne serwisy, w naszym przypadku `PhotoSerializer`).








