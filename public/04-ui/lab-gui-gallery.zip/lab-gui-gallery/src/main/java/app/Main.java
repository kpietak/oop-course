package app;

import javafx.application.Application;

public class Main {

    public static final String GOOGLE_CUSTOM_SEARCH_API_KEY = "*** Enter your https://www.scraperapi.com API key HERE ***";


    public static void main(String[] args) {
        Application.launch(GalleryApp.class);
    }
}
